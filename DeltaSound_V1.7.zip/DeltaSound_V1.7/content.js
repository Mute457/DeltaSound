(() => {
  const DURATION_MS = 2500;      // tempo que o texto fica visível
  const FADE_MS = 500;           // tempo do efeito de desaparecer
  const DRIFT_PX = 24;           // distância do movimento (mesma velocidade de antes)
  const FROM = 'right';          // de onde o texto vem: 'right' (vem da direita) ou 'left' (vem da esquerda)
  const SCALE = 3;               // tamanho de cada "pixel" na tela
  const MAX_CHARS = 60;
  const FILL = '#ffffff';        // cor da letra
  const OUTLINE = '#101D8D';     // cor do contorno
  const SHOW_ON_RESUME = true;   // mostrar de novo quando o som volta depois de uma pausa
  const MIN_SILENCE_MS = 3000;   // pausa mínima para contar como "voltou o som"
  const POLL_MS = 500;

  // Players de pré-visualização (ex.: ao passar o mouse sobre um vídeo no YouTube)
  const PREVIEW_SELECTOR = [
    'ytd-video-preview', '#video-preview', '#inline-preview-player',
    'ytd-thumbnail', 'yt-lockup-view-model', 'ytd-rich-item-renderer',
    'ytd-compact-video-renderer', 'ytd-grid-video-renderer'
  ].join(',');

  let root = null;
  let anim = null;
  let lastShownTitle = '';
  let wasPlaying = false;
  let silentSince = Date.now();

  function hexToRgb(hex) {
    const n = parseInt(hex.slice(1), 16);
    return [(n >> 16) & 255, (n >> 8) & 255, n & 255];
  }
  const FILL_RGB = hexToRgb(FILL);
  const OUTLINE_RGB = hexToRgb(OUTLINE);

  // Remove acentos (ã→a, é→e, ç→c...) e troca símbolos que a fonte não tem
  function removeAccents(t) {
    return t
      .normalize('NFD')
      .replace(/[\u0300-\u036f]/g, '')
      .replace(/[\u2010-\u2015]/g, '-')
      .replace(/\u2026/g, '...')
      .replace(/\u00a0/g, ' ');
  }

  function getTitle() {
    try {
      const md = navigator.mediaSession && navigator.mediaSession.metadata;
      if (md && md.title) return md.title.trim();
    } catch (e) {}
    const ytm = document.querySelector('ytmusic-player-bar .title');
    if (ytm && ytm.textContent) return ytm.textContent.trim();
    return '';
  }

  // Há som tocando na página? (mídia rodando, sem mudo, com volume, fora de previews)
  function isSoundPlaying() {
    const els = document.querySelectorAll('video, audio');
    for (const el of els) {
      if (el.paused || el.ended || el.muted || el.volume === 0) continue;
      if (el.readyState < 3 || el.currentTime <= 0) continue;
      if (el.closest && el.closest(PREVIEW_SELECTOR)) continue;
      return true;
    }
    if (els.length === 0) {
      try {
        return navigator.mediaSession.playbackState === 'playing';
      } catch (e) {}
    }
    return false;
  }

  // Monta o texto pixel a pixel a partir dos bitmaps da fonte (font.js)
  function renderPixelText(title) {
    let clean = removeAccents(title);
    if (clean.length > MAX_CHARS) clean = clean.slice(0, MAX_CHARS - 3) + '...';
    const text = '\u266A~ ' + clean; // ♪~ + título

    const F = self.PIXEL_FONT;
    const glyphs = [];
    let textW = 0;
    for (const ch of text) {
      const g = F.glyphs[ch] || F.glyphs['?'] || F.glyphs[' '];
      glyphs.push(g);
      textW += g[0];
    }

    const pad = 2;
    const W = textW + pad * 2;
    const H = F.rows + pad * 2;
    const mask = new Uint8Array(W * H);

    let x = pad;
    for (const g of glyphs) {
      const off = g[1];
      for (let r = 0; r < F.rows; r++) {
        const bits = g[2 + r];
        for (let c = 0; c < 20; c++) {
          if ((bits >> c) & 1) {
            const px = x + off + c;
            if (px >= 0 && px < W) mask[(pad + r) * W + px] = 1;
          }
        }
      }
      x += g[0];
    }

    // Desenha 1 pixel por pixel num canvas pequeno; o CSS amplia sem suavizar
    const out = document.createElement('canvas');
    out.width = W; out.height = H;
    out.style.cssText =
      `width:${W * SCALE}px;height:${H * SCALE}px;image-rendering:pixelated;display:block;`;
    const o = out.getContext('2d');
    const img = o.createImageData(W, H);
    const d = img.data;
    for (let y = 0; y < H; y++) {
      for (let xx = 0; xx < W; xx++) {
        let rgb = null;
        if (mask[y * W + xx]) {
          rgb = FILL_RGB;
        } else {
          for (let dy = -1; dy <= 1 && !rgb; dy++) {
            for (let dx = -1; dx <= 1; dx++) {
              const ny = y + dy, nx = xx + dx;
              if (ny >= 0 && ny < H && nx >= 0 && nx < W && mask[ny * W + nx]) {
                rgb = OUTLINE_RGB;
                break;
              }
            }
          }
        }
        if (rgb) {
          const i = (y * W + xx) * 4;
          d[i] = rgb[0]; d[i + 1] = rgb[1]; d[i + 2] = rgb[2]; d[i + 3] = 255;
        }
      }
    }
    o.putImageData(img, 0, 0);
    return out;
  }

  // Entra e sai com a mesma animação: fade + deslize lento na mesma direção e velocidade
  function show(title) {
    if (!root) {
      root = document.createElement('div');
      root.style.cssText =
        `position:fixed;top:16px;left:${16 + (FROM === 'left' ? DRIFT_PX : 0)}px;z-index:2147483647;` +
        'pointer-events:none;opacity:0;will-change:transform,opacity;';
      document.documentElement.appendChild(root);
    }
    root.replaceChildren(renderPixelText(title));
    if (anim) anim.cancel();
    const total = DURATION_MS + FADE_MS;
    const start = FROM === 'left' ? -DRIFT_PX : DRIFT_PX;
    anim = root.animate([
      { opacity: 0, transform: `translateX(${start}px)`, offset: 0 },
      { opacity: 1, offset: FADE_MS / total },          // fade in (mesma duração do fade out)
      { opacity: 1, offset: DURATION_MS / total },
      { opacity: 0, transform: 'translateX(0px)', offset: 1 }
    ], { duration: total, easing: 'linear', fill: 'forwards' });
  }

  function check() {
    const playing = isSoundPlaying();
    const now = Date.now();
    const title = playing ? getTitle() : '';

    if (playing && title) {
      const newSong = title !== lastShownTitle;
      const resumed = SHOW_ON_RESUME && !wasPlaying && (now - silentSince) > MIN_SILENCE_MS;
      if (newSong || resumed) {
        lastShownTitle = title;
        show(title);
      }
    } else if (wasPlaying) {
      silentSince = now;
    }
    wasPlaying = playing && !!title;
  }

  setInterval(check, POLL_MS);
  // reage na hora quando o player toca/pausa
  ['play', 'playing', 'pause', 'ended', 'emptied'].forEach(ev =>
    document.addEventListener(ev, check, true));
})();
